'''
ECE276A WI21 PR1: Color Classification and Recycling Bin Detection
'''

from generate_rgb_data import read_pixels
import numpy as np

class PixelClassifier():
  def __init__(self):
    '''
	    Initilize your classifier with any parameters and attributes you need
    '''
    self.y = np.empty((0,1), int)
    pass

  def classify(self,X):
    '''
	    Classify a set of pixels into red, green, or blue
	    
	    Inputs:
	      X: n x 3 matrix of RGB values
	    Outputs:
	      y: n x 1 vector of with {1,2,3} values corresponding to {red, green, blue}, respectively
    '''
    mu,sig = self.train()
    for i in range(np.shape(X)[0]):
        h1 = np.sum((np.log(sig[0]**2)) + ((X[i] - mu[0])**2/sig[0]**2)); #red
        h2 = np.sum((np.log(sig[1]**2)) + ((X[i] - mu[1])**2/sig[1]**2)); #green
        h3 = np.sum((np.log(sig[2]**2)) + ((X[i] - mu[2])**2/sig[2]**2)); #blue
        h = np.vstack((h1,h2,h3))
        max_h = np.argmax(h) + 1
        self.y = np.append(self.y,[[max_h]])
    return self.y

  def train(self):
    ''' Use the provided training data to create a model for a Naive Bayes discriminant'''
    folder = 'data/training'
    X1 = read_pixels(folder+'/red')
    X2 = read_pixels(folder+'/green')
    X3 = read_pixels(folder+'/blue')
    mu1 = X1.mean(axis = 0)
    mu2 = X2.mean(axis = 0)
    mu3 = X3.mean(axis = 0)
    sig1 = np.sqrt(np.sum((X1 - mu1)**2,axis = 0)/np.shape(X1)[0])
    sig2 = np.sqrt(np.sum((X2 - mu2)**2,axis = 0)/np.shape(X2)[0])
    sig3 = np.sqrt(np.sum((X3 - mu3)**2,axis = 0)/np.shape(X3)[0])
    mu, sig = np.vstack((mu1,mu2,mu3)), np.vstack((sig1,sig2,sig3))
    return mu, sig
